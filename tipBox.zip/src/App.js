import Whitebox from "./whitebox/whitebox";

function App() {
  return (
    <div>
       <Whitebox />
    </div>
  );
}

export default App;
